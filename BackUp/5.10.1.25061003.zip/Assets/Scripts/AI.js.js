// @input string question = "What are some ideas for Lenses?"
// @input Component.Text outputDisplay

const request = {
  temperature: 1,
  messages: [{ role: 'user', content: script.question }],
};

function requestGPT() {
  print(`Requesting answer for: ${script.question}`);

  global.chatGpt.completions(request, (errorStatus, response) => {
    if (!errorStatus && typeof response === 'object') {
      const mainAnswer = response.choices[0].message.content;
      print(mainAnswer);
      script.outputDisplay.text = mainAnswer;
    } else {
      print(JSON.stringify(response));
    }
  });
}

script.createEvent('TapEvent').bind(requestGPT);
print('Tap to call GPT!');